package com.library.dto.response;

public class ResponseMessage {

    public final static String IMAGE_UPDATE_MESSAGE = "Image  successfully uploaded";

    public final static String DELETE_MESSAGE = "Delete was done successfully";
}